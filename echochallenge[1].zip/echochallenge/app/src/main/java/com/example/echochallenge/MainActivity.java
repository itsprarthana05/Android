package com.example.echochallenge;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Challenge> challengeList;
    EchoChallengeAdapter adapter;
    ProgressDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerChallenges);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new ProgressDBHelper(this);

        challengeList = new ArrayList<>();
        challengeList.add(new Challenge(1, "Tree Plantation", "Plant a tree to make the environment green.", R.drawable.img_1));
        challengeList.add(new Challenge(2, "Plastic-Free Day", "Avoid plastic usage for one day.", R.drawable.plastic));
        challengeList.add(new Challenge(3, "Clean Local Area", "Clean your surroundings or society.", R.drawable.img));
        challengeList.add(new Challenge(4, "Save Water", "Save water for one day.", R.drawable.savewater));
        challengeList.add(new Challenge(5, "Watering a Tree", "Be the reason a tree stands tall—water it today!", R.drawable.watering));
        challengeList.add(new Challenge(6, "Recycle the E-Waste", "Old Gadgets, New Life – Recycle Right!", R.drawable.ewaste));

        adapter = new EchoChallengeAdapter(this, challengeList, challenge -> {

            boolean isAccepted = dbHelper.isChallengeAccepted(challenge.getTitle());

            if (isAccepted) {
                // Already accepted: open challenge directly
                openChallengeDetails(challenge);
            } else {
                // Show custom alert dialog
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Accept Challenge")
                        .setMessage("Do you want to accept this challenge?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            // Set initial progress 0% to mark as accepted
                            dbHelper.updateProgress(challenge.getTitle(), 0);
                            openChallengeDetails(challenge);
                        })
                        .setNegativeButton("No", null) // No action
                        .setCancelable(false)
                        .show();
            }
        });

        recyclerView.setAdapter(adapter);

        // Optional: create/open DB
        SQLiteDatabase db = dbHelper.getWritableDatabase();
    }

    private void openChallengeDetails(Challenge challenge) {
        Intent intent = new Intent(MainActivity.this, ChallengeDetailsActivity.class);
        intent.putExtra("challengeId", challenge.getId());
        intent.putExtra("title", challenge.getTitle());
        intent.putExtra("desc", challenge.getDescription());
        intent.putExtra("imageRes", challenge.getImageResId());
        startActivity(intent);
    }
}
