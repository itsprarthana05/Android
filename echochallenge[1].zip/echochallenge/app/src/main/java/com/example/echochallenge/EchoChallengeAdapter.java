package com.example.echochallenge;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class EchoChallengeAdapter extends RecyclerView.Adapter<EchoChallengeAdapter.EchoViewHolder> {

    private Context context;
    private List<Challenge> challengeList;
    private OnEchoClickListener listener;

    public interface OnEchoClickListener {
        void onItemClick(Challenge challenge);
    }

    public EchoChallengeAdapter(Context context, List<Challenge> challengeList, OnEchoClickListener listener) {
        this.context = context;
        this.challengeList = challengeList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EchoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_echo_challenge, parent, false);
        return new EchoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EchoViewHolder holder, int position) {
        Challenge challenge = challengeList.get(position);
        holder.title.setText(challenge.getTitle());
        holder.desc.setText(challenge.getDescription());

        if (challenge.getImageUri() != null) {
            Glide.with(context)
                    .load(Uri.parse(challenge.getImageUri()))
                    .into(holder.image);
        } else {
            holder.image.setImageResource(challenge.getImageResId());
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(challenge));
    }

    @Override
    public int getItemCount() {
        return challengeList.size();
    }

    public static class EchoViewHolder extends RecyclerView.ViewHolder {
        TextView title, desc;
        ImageView image;

        public EchoViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.echoChallengeTitle);
            desc = itemView.findViewById(R.id.echoChallengeDesc);
            image = itemView.findViewById(R.id.echoChallengeImage);
        }
    }
}
