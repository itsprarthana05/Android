package com.example.echochallenge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.util.ArrayList;

public class ChallengeDetailsActivity extends AppCompatActivity {

    TextView titleView, descView, progressText;
    ProgressBar progressBar;
    ImageView image1, image2;
    Button btnUpload, btnSubmit;
    CheckBox cbDone;

    String title;
    int progress = 0;

    ArrayList<Uri> uploadedImages = new ArrayList<>();
    ProgressDBHelper dbHelper;

    static final int PICK_IMAGE = 100;
    static final int CAPTURE_IMAGE = 101;
    Uri imageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_challenge_details);

        titleView = findViewById(R.id.challengeTitle);
        descView = findViewById(R.id.challengeDesc);
        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressPercent);
        image1 = findViewById(R.id.uploadedImage1);
        image2 = findViewById(R.id.uploadedImage2);
        btnUpload = findViewById(R.id.btnUploadImage);
        btnSubmit = findViewById(R.id.btnSubmit);
        cbDone = findViewById(R.id.checkBoxComplete);

        title = getIntent().getStringExtra("title");
        String desc = getIntent().getStringExtra("desc");

        titleView.setText(title);
        descView.setText(desc);

        dbHelper = new ProgressDBHelper(this);

        // Load previous progress and images
        progress = dbHelper.getProgress(title);
        updateProgress(progress);
        loadImages();

        btnUpload.setOnClickListener(v -> showImagePickerDialog());

        btnSubmit.setOnClickListener(v -> {
            if (cbDone.isChecked()) {
                if (uploadedImages.size() < 2) {
                    Toast.makeText(this, "Upload at least 2 images before submission!", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHelper.updateProgress(title, 100);
                updateProgress(100);
                saveUploadedImages();

                Toast.makeText(this, "Challenge Completed!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please check 'Task Completed' to submit!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showImagePickerDialog() {
        String[] options = {"Choose from Gallery", "Take Photo"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Image");
        builder.setItems(options, (dialog, which) -> {
            if (which == 0) openGallery();
            else openCamera();
        });
        builder.show();
    }

    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    private void openCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Pic");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From Camera");
        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(cameraIntent, CAPTURE_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == PICK_IMAGE && data != null) {
                imageUri = data.getData();
            }

            if (requestCode == CAPTURE_IMAGE || requestCode == PICK_IMAGE) {
                if (imageUri != null) {
                    try {
                        InputStream inputStream = getContentResolver().openInputStream(imageUri);
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                        handleImageUpload(bitmap, imageUri);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(this, "Image URI is null", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void handleImageUpload(Bitmap bitmap, Uri uri) {
        if (uploadedImages.size() == 0) {
            image1.setImageBitmap(bitmap);
            uploadedImages.add(uri);
            updateProgress(50);
        } else if (uploadedImages.size() == 1) {
            image2.setImageBitmap(bitmap);
            uploadedImages.add(uri);
            updateProgress(75);
        } else {
            Toast.makeText(this, "You have already uploaded 2 images.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateProgress(int value) {
        progress = value;
        progressBar.setProgress(value);
        progressText.setText(value + "% Completed");
    }

    private void loadImages() {
        ArrayList<String> savedPaths = dbHelper.getUploadedImagePaths(title);
        uploadedImages.clear();

        if (savedPaths != null) {
            if (savedPaths.size() > 0) {
                String path1 = savedPaths.get(0);
                Bitmap bitmap1 = BitmapFactory.decodeFile(path1);
                if (bitmap1 != null) {
                    image1.setImageBitmap(bitmap1);
                    uploadedImages.add(Uri.fromFile(new java.io.File(path1)));
                    updateProgress(50);
                }
            }

            if (savedPaths.size() > 1) {
                String path2 = savedPaths.get(1);
                Bitmap bitmap2 = BitmapFactory.decodeFile(path2);
                if (bitmap2 != null) {
                    image2.setImageBitmap(bitmap2);
                    uploadedImages.add(Uri.fromFile(new java.io.File(path2)));
                    updateProgress(75);
                }
            }

            if (dbHelper.getProgress(title) == 100) {
                updateProgress(100);
                cbDone.setChecked(true);
            }
        }
    }

    private void saveUploadedImages() {
        ArrayList<String> savedPaths = new ArrayList<>();
        for (int i = 0; i < uploadedImages.size(); i++) {
            Uri uri = uploadedImages.get(i);
            String filename = title.replaceAll(" ", "_") + "_img" + (i + 1) + ".jpg";
            String path = saveImageToInternalStorage(uri, filename);
            if (path != null) {
                savedPaths.add(path);
            }
        }
        dbHelper.saveImagePaths(title, savedPaths);
    }

    private String saveImageToInternalStorage(Uri uri, String fileName) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            java.io.File file = new java.io.File(getFilesDir(), fileName);
            java.io.OutputStream outputStream = new java.io.FileOutputStream(file);

            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, len);
            }

            outputStream.close();
            inputStream.close();

            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
