package com.example.echochallenge;

public class Challenge {
    private int id;
    private String title;
    private String description;
    private int imageResId;
    private String imageUri; // for gallery image

    // Constructor with default image resource
    public Challenge(int id, String title, String description, int imageResId) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.imageResId = imageResId;
    }

    // Constructor with imageUri
    public Challenge(int id, String title, String description, String imageUri) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.imageUri = imageUri;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }
}
