package com.example.echochallenge;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.ArrayList;

public class ProgressDBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "progress.db";
    private static final int DB_VERSION = 1;

    private static final String TABLE_NAME = "challenge_progress";
    private static final String COL_TITLE = "title";
    private static final String COL_PROGRESS = "progress";
    private static final String COL_IMAGE1 = "image1";
    private static final String COL_IMAGE2 = "image2";
    public ProgressDBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_TITLE + " TEXT PRIMARY KEY, " +
                COL_PROGRESS + " INTEGER, " +
                COL_IMAGE1 + " TEXT, " +
                COL_IMAGE2 + " TEXT)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void saveImagePaths(String title, ArrayList<String> paths) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_TITLE, title);
        values.put(COL_PROGRESS, 100);  // Mark as completed

        if (paths.size() > 0) values.put(COL_IMAGE1, paths.get(0));
        if (paths.size() > 1) values.put(COL_IMAGE2, paths.get(1));

        db.insertWithOnConflict(TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public ArrayList<String> getUploadedImagePaths(String title) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> paths = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_TITLE + "=?", new String[]{title});

        if (cursor.moveToFirst()) {
            String img1 = cursor.getString(cursor.getColumnIndexOrThrow(COL_IMAGE1));
            String img2 = cursor.getString(cursor.getColumnIndexOrThrow(COL_IMAGE2));

            if (img1 != null) paths.add(img1);
            if (img2 != null) paths.add(img2);
        }

        cursor.close();
        db.close();
        return paths;
    }

    public void updateProgress(String title, int progress) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PROGRESS, progress);

        int updated = db.update(TABLE_NAME, values, COL_TITLE + "=?", new String[]{title});
        if (updated == 0) {
            values.put(COL_TITLE, title);
            db.insert(TABLE_NAME, null, values);
        }

        db.close();
    }


        public int getProgress(String title) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_TITLE + "=?", new String[]{title});
        int progress = 0;

        if (cursor.moveToFirst()) {
            progress = cursor.getInt(cursor.getColumnIndexOrThrow(COL_PROGRESS));
        }

        cursor.close();
        db.close();
        return progress;
    }

    // ✅ Fixed: Not nested & returns boolean
    public boolean isChallengeAccepted(String title) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT progress FROM " + TABLE_NAME + " WHERE title = ?", new String[]{title});

        boolean accepted = false;
        if (cursor.moveToFirst()) {
            int progress = cursor.getInt(0);
            accepted = progress >= 0; // If entry exists, it's accepted
        }

        cursor.close();
        db.close();
        return accepted;
    }
}
