package com.example.animationpr;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView img;
    Button b1, b2, b3, b4, b5, b6;

    Animation animationClockwise, animationAntiClockwise, animationZoomIn, animationZoomOut, animationFadeIn, animationFadeOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        img = findViewById(R.id.image);
        b1 = findViewById(R.id.clockwise);
        b2 = findViewById(R.id.anticlockwise);
        b3 = findViewById(R.id.zoom_in);
        b4 = findViewById(R.id.zoom_out);
        b5 = findViewById(R.id.fade_in);
        b6 = findViewById(R.id.fade_out);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);

        animationClockwise = AnimationUtils.loadAnimation(this, R.anim.clockwise);
        animationAntiClockwise = AnimationUtils.loadAnimation(this, R.anim.anticlockwise);
        animationZoomIn = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
        animationZoomOut = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
        animationFadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        animationFadeOut = AnimationUtils.loadAnimation(this, R.anim.fade_out);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.clockwise:
                img.startAnimation(animationClockwise);
                break;
            case R.id.anticlockwise:
                img.startAnimation(animationAntiClockwise);
                break;
            case R.id.zoom_in:
                img.startAnimation(animationZoomIn);
                break;
            case R.id.zoom_out:
                img.startAnimation(animationZoomOut);
                break;
            case R.id.fade_in:
                img.startAnimation(animationFadeIn);
                break;
            case R.id.fade_out:
                img.startAnimation(animationFadeOut);
                break;
            default:
                break;
        }
    }
}
